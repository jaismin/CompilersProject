var str="jrhvufbv\nkrhfirbf\njb\njrbv"
package examples

/** Quick sort, \n \n  imperative style */
object sort {

  /** Nested methods can use and even update everything 
   *  visible \n \n  in their scope (including local variables or 
   *  arguments of enclosing methods). 
   */
  def sort(a: Array[Int]) {