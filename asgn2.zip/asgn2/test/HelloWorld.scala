class Point(val xc: Int, val yc: Int) 
{
   var x: Int = xc;
   var y: Int = yc;
   if ((Double)x>0)
      {
         x=x+600;
      }
}


object Test123 
{

	object Test345 
		{
		   a=4;    
		}
}

object sort 
{

  object abc extends cdv
  {
    println("Hello World");
    object xdf
    {
      ;
    }


  }

	  var (a:Int,b:Double)=(2,8,9,f(j));
	  var (a:Int,b:Double)=(2,8,9,a[j]);
	  var (a:Int,b:Double)=(2,8,9,obj.j);
	  var (a:Int,b:Double)=(2,8,9,t);
	  var (a:Int,b:Double)=(2,8,9,j);
	  var (a:Int,b:Double)=(2,8,9,j);

	  val (a:Int,b:Double)=(2,8,9,f(j));
	  val (a:Int,b:Double)=(2,8,9,a[j]);
	  val (a:Int,b:Double)=(2,8,9,obj.j);
	  val (a:Int,b:Double)=(2,8,9,t);
	  val (a:Int,b:Double)=(2,8,9,j);
	  val (a:Int,b:Double)=(2,8,9,j);

	  val a:String=4;
	  var we:Boolean=4;



	  a=(76+90)*76 ;
	  b=1 << (a + b);
	  ans = msub(1 << (a + b), (minv(m.val1) * (phi[m / i] * 2 / gcd(a + b, b))) % MOD); 
	  var (ans:Int) = (msub(1 << (a + b), (minv(m.val1) * (phi[m / i] * 2 / gcd(a + b, b))) % MOD)); 

		if((num%2)==0) //checking whether remainder is 0 or not. 
		{
		  a=23;
		  b=23;
		}
		else if((num%2)==0)
		g=78;
		else
		{
		  a=23;
		  b=23;
		}


	 while( a < 20 ){
	         println( "Value of a: " + a );
	         a=a+0;
	         a = a + 1;
	      }

	do
	{
	   println( "Value of a: " + a );
	   a = a + 1;
	} while( a < 20 );


	return 100 ;
}


object Test123 
{
 
private def main() : Unit = 
{
      
	val z:Int=1;
    if (z < 21)
   {
      class Point123() 
      {
     
        println ("Point y location : ");
        println ("Point z location : ");

      }
   }

  loc.move(10, 10, 5);
  println( "Returned Value : " + addInt(5,7) );
}

def addInt(a:Int,b:Int) : Int = 
{
      var sum:Int = 0;
      sum = a + b;

      return sum;
}


}

object sort 
{

  var (z:Array[String],z:Array[String],loc:Location) = (new Array[String](3),Array("Zara", "Nuha", "Ayan"),new Location(10, 20, 15));
  

}

class Point(val xc: Int, val yc: Int) {
   var x: Int = xc;
   var y: Int = yc;



  	var z:Array[Location] = new Array[String](3);
	var z:Array[String] = new Array[String](3);
	var z:Array[Array[String]] = new Array[Array[String]](3);

   println("Yeah"+X);
   if (x>0)
      {
         x=x+600;
      }
  
   def move(dx: Int, dy: Int) : Unit = {
      x = x + dx;
      y = y + dy;
      println ("Point x location : " + x);
      println ("Point y location : " + y);
   }

	(2+3) match 
	{
	  case 0 => ;
	  case 23 => ;
	  case 1  => println("January");
	  case 2  => println("February");
	  case 3  => println("March");
	  case 4  => println("April");
	  case 5  => println("May");
	  case 6  => println("June");
	  case 7  => println("July");
	  case 8  => println("August");
	  case 9  => println("September");
	  case 10 => println("October");
	  case 11 => println("November");
	  case 12 => println("December");
	  // catch the default with a variable so you can print it
	  case _  => println("Unexpected case: " + whoa.toString);
	}
}


