object Test {
   def main(args: Array[String]):String = {
      val x:Int = 4;
      val y:Int = 5;
      x = y + 1;
   }
}